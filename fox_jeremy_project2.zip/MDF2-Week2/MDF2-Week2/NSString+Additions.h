//
//  NSString+Additions.h
//  MDF2-Week2
//
//  Created by Jeremy Fox on 11/27/12.
//  Copyright (c) 2012 Jeremy Fox. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Additions)

+ (int)getHeightForString:(NSString *)inputString font:(UIFont *)font;

@end
