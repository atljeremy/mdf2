//
//  Constants.h
//  MDF2-Week1
//
//  Created by Jeremy Fox on 11/24/12.
//  Copyright (c) 2012 Jeremy Fox. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kUserSelectedDefaultCalendar @"UserSelectedDefaultCalendar"

@interface Constants : NSObject

@end
