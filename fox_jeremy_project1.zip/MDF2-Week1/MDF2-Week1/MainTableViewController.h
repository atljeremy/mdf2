//
//  MainTableViewController.h
//  MDF2-Week1
//
//  Created by Jeremy Fox on 11/20/12.
//  Copyright (c) 2012 Jeremy Fox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTableViewController : UITableViewController

@end
