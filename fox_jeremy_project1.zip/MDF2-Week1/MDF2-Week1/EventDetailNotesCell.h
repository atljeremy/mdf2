//
//  EventDetailNotesCell.h
//  MDF2-Week1
//
//  Created by Jeremy Fox on 11/24/12.
//  Copyright (c) 2012 Jeremy Fox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventDetailNotesCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UITextView *notes;

@end
