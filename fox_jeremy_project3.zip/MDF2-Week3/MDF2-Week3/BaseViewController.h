//
//  BaseViewController.h
//  MDF2-Week3
//
//  Created by Jeremy Fox on 12/6/12.
//  Copyright (c) 2012 Jeremy Fox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
